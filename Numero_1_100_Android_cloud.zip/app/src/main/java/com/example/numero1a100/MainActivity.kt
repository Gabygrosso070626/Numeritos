package com.example.numero1a100

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.LinearLayout
import java.util.Random

class MainActivity : Activity() {
 private val random=Random()
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
  val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setBackgroundColor(Color.BLACK); setPadding(24,24,24,24) }
  val number=TextView(this).apply { text="—"; setTextColor(Color.WHITE); textSize=150f; gravity=Gravity.CENTER; setTypeface(null,Typeface.BOLD); includeFontPadding=false }
  val button=Button(this).apply { text="GENERAR NÚMERO"; textSize=18f; isAllCaps=false; setOnClickListener { number.text=(random.nextInt(100)+1).toString() } }
  layout.addView(number, LinearLayout.LayoutParams(-1,0,1f))
  layout.addView(button, LinearLayout.LayoutParams(-1,-2))
  setContentView(layout)
 }
}
